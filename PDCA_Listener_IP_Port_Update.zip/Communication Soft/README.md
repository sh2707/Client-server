# Communication Soft (source)

- Windows WPF / .NET Framework 4.8 project.
- Six machine rows have editable names, target IPs and ports. Use **Save Name** or **Save Machine Settings**; settings are stored in `Config/machines.csv` beside the application.
- Date/time is shown in `dd-MM-yyyy` and 24-hour `HH:mm:ss` format.
- Select target machine and SN type. MLB accepts 18 alphanumeric characters and Load MLB File reads unique 18-character entries from TXT/CSV lines. PANEL SN requires 23 characters; JIG SN requires 14.
- Queue Data queues a single serial; Load MLB File queues multiple unique MLB SN entries. Press **START Selected Machine** to send queued DATA commands and then START to only that PDCA Sender instance.
- TCP protocol: `PING`, `DATA|MLB SN|<serial>`, `DATA|PANEL SN|<serial>`, `DATA|JIG SN|<serial>`, and `START`, one command per line.
- Default PDCA Sender input port is TCP 56379. Allow inbound TCP 56379 in Windows Firewall on each PDCA Sender PC. Configure each machine row to that PC's LAN IP.
- Build in Visual Studio on Windows using .NET Framework 4.8 developer pack. This ZIP contains source, not prebuilt executables.

## Important test note
This project bundle was assembled from the uploaded PDCA Sender source and the new Communication Soft source. It has not been compiled or tested against your actual LAN/server. Please test with one spare machine and confirm the server/query behavior before deploying to all six PCs.
