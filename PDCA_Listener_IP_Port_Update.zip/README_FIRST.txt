PDCA Sender + Communication Soft source bundle

Folders:
1. PDCA Sender-Sh - uploaded PDCA Sender source, with a TCP input listener added on port 56379.
2. Communication Soft - new six-machine controller source with editable machine names, IP/port, date/time, MLB file loading, queue and START.

Build both projects separately in Visual Studio on Windows with .NET Framework 4.8 Developer Pack. This is source code only; no compiled EXE is included.

Communication Soft sends DATA|TYPE|SERIAL commands and then START to the selected machine. PDCA Sender queues received data and only begins processing when START is received. The incoming type is mapped to the existing SN type selector and uses the current Query/Template processing workflow.

Default listener port: 56379/TCP. Add a Windows Firewall inbound rule on each PDCA Sender PC and set the correct LAN IP in Communication Soft.

PLEASE NOTE: This is an initial integration source package and has not been compiled or validated against your production server. Test one machine first.
